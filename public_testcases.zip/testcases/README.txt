First line contains two integers m and n representing the number of rows and columns respectively.
next m line contains n integers each representing the array elements of first array
next m line contains n integers each representing the array elements of second array